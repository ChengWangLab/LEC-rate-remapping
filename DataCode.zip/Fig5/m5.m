load('brain-region-spatial-res', 'lec_s_info', 'mec_s_info', 'ca1_s_info','ca3_s_info');

figure('position', [722   559   641   135]);
tick_length = 0.015*ones(1, 2); 
subplot(1, 3, 1);
Y = {lec_s_info, mec_s_info, ca3_s_info, ca1_s_info};
h = plotSpread(Y); hold on;
for i = 1:4
    plot(i, median(Y{i}), '.', 'markersize', 10, 'color', 'k');
end

set(gca, 'tickdir', 'out','ticklength', tick_length,'ylim',[0, 3],'xlim', [0.5, 4.5]);
for i = 1:4
    set(h{1}(i), 'markersize', 3, 'color', [.6 .6 .6]);
end
ylabel('Spatial Information');
subplot(1, 3, 2);
load('brain-region-time-res', 'lec_t_info', 'mec_t_info', 'ca1_t_info','ca3_t_info');
Y = {lec_t_info, mec_t_info, ca3_t_info, ca1_t_info};
h = plotSpread(Y); hold on;
for i = 1:4
    plot(i, median(Y{i}), '.', 'markersize', 10, 'color', 'k');
end
set(gca, 'tickdir', 'out','ticklength', tick_length,'ylim',[0, 1],'xlim', [0.5, 4.5]);
for i = 1:4
    set(h{1}(i), 'markersize', 3, 'color', [.6 .6 .6]);
end
ylabel('Temporal Information');

load('cross-brain-region-cc', 'ca1_std_cc', 'ca3_std_cc', 'lec_std_cc', 'mec_std_cc')

subplot(1, 3, 3)
tick_length = 0.015*ones(1, 2); 
Y = {lec_std_cc, mec_std_cc, ca3_std_cc, ca1_std_cc};
h = plotSpread(Y); hold on;
for i = 1:4
    plot(i, median(Y{i}), '.', 'markersize', 10, 'color', 'k');
end
set(gca, 'tickdir', 'out','ticklength', tick_length,'ylim',[-1, 1],'xlim', [0.5, 4.5]);
for i = 1:4
    set(h{1}(i), 'markersize', 3, 'color', [.6 .6 .6]);
end
ylabel('Consistency of Temporal Modulation Field');

