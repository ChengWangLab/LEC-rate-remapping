
load('band-plot-data.mat', 'names', 'data');
for i = 1:5
    subplot(1, 5, i);
    mycdfplot(data{i}.lat, 'color', 'r'); hold on;
    mycdfplot(data{i}.int, 'color', 'b');
    mycdfplot(data{i}.med, 'color', [0.5, 0.5, 0.5]);
    set(gca, 'tickdir', 'out', 'ticklength', [0.05, 0.05]); box off; 
    title(names{i});
end
