ccc; load('shuf-dyna.mat', 'upres', 'dnres');
load('real-dyna.mat', 'res');
upres = upres([1,3,5], :); upres = upres';
dnres = dnres([1,3,5], :); dnres = dnres';

plot(upres(:), 'r'); hold on; 
plot(dnres(:), 'b');
plot(res(2:end), 'k')


ccc; 
 cd '/media/data/data/oldmanu/mine/ref/newtrack/revise/decode';
init_science_fig(3);
set(gcf, 'position', [13.5202   16.7481   17.0127    4.0481]);
load('mec-shuf-dyna.mat', 'upres', 'dnres');
load('mec-real-dyna.mat', 'res');
upres = upres([1,3,5], :); upres = upres';
dnres = dnres([1,3,5], :); dnres = dnres';

subplot(1, 2, 2);
plot(upres(:), 'color', ones(1,3)*.5); hold on; 
plot(dnres(:),'color', ones(1,3)*.5);
res(1,1) = nan;
plot(res(1:end), 'r'); 
set(gca, 'ylim', [-0.2, 1], 'xlim', [1, 42], 'tickdir', 'out');
box off;
plot([15, 15]-0.5, [-0.2, 1], 'k--');
plot([29, 29]-0.5, [-0.2, 1], 'k--');
subplot(1, 2, 1);
load('shuf-dyna.mat', 'upres', 'dnres');
load('real-dyna.mat', 'res');
upres = upres([1,3,5], :); upres = upres';
dnres = dnres([1,3,5], :); dnres = dnres';

plot(upres(:), 'color', ones(1,3)*.5); hold on; 
plot(dnres(:), 'color', ones(1,3)*.5);
res(1) = nan;
plot(res(1:end), 'b');
set(gca, 'ylim', [-0.2, 1], 'xlim', [1, 42], 'tickdir', 'out');
box off;
plot([15, 15]-0.5, [-0.2, 1], 'k--');
plot([29, 29]-0.5, [-0.2, 1], 'k--');
ylabel('Population correlation');
xlabel('Lap number');
cd '/media/data/data/oldmanu/mine/ref/newtrack/revise/fig/review3';
% SaveFigure('stability')



load('lec-mec-cmp-popu.mat', 'shuffled', 'observed');

init_science_fig(3);
set(gcf, 'position', [13.5202   16.7481   17.0127    4.0481]);
set(gcf, 'position', [11.6417   15.8485    9.1281    3.0162]);
edges = -0.4:0.02:0.4;
t = histc(shuffled, edges);
t = t(1:end-1); x = edges(1:end-1) + 0.02/2;
bar(x, t);
hold on;
plot([observed, observed], [0, 100]);
set(gca, 'xlim', [-0.4, 0.4], 'tickdir', 'out'); box off;

