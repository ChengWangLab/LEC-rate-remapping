%
load('circtrack-tim-cc-permtest', 'circ1d');
load('dr-mis-data.mat', 'tim_1', 'tim_2', 'realres', 'permres');

edges = -0.2:0.02:0.2;
tick_length = 0.03;
xc = edges(1:end-1) + 0.01;
figure;
set(gcf, 'position', [680   728   459   137]);
subplot(1, 2, 1);
dry = histc(permres, edges);
dry = dry(1:end-1);
bar(xc, dry, 'w', 'edgecolor', 'k'); hold on; plot([realres, realres], [0, 100], 'r');
set(gca, 'xlim', [-0.3, 0.3]); box off; box off; set(gca, 'tickdir', 'out', 'ticklength', [tick_length, tick_length]);
title('DR')
subplot(1, 2, 2);
myy = histc(circ1d.allpermres, edges);
myy = myy(1:end-1);
bar(xc, myy, 'w', 'edgecolor','k'); hold on; plot([circ1d.allrealres, circ1d.allrealres], [0, 100], 'r');
set(gca, 'xlim', [-0.3, 0.3]); box off; set(gca, 'tickdir', 'out', 'ticklength', [tick_length, tick_length]);
title('circ')
