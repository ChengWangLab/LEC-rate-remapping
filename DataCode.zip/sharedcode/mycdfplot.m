function h = mycdfplot(x, varargin)
%MYCDFPLOT
%   h = MYCDFPLOT(x, varargin)
%
%   Input:
%       x(vec) - data to be ploted
%       varargin() - varargin for input
%   Output:
%       h(handle) -
%
%   Notes:
%
%   See also
%
%   by Cheng Wang (cwchengwang@gmail.com), 2015-10-01.


[yy,xx,~,~,eid] = cdfcalc(x);
% Create vectors for plotting
k = length(xx);
n = reshape(repmat(1:k, 2, 1), 2*k, 1);
xCDF    = [-Inf; xx(n); Inf];
yCDF    = [0; 0; yy(1+n)];

h = plot(xCDF, yCDF, varargin{:});

return;
