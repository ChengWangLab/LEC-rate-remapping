load Fig2b-c.mat
subplot(1, 3, 1);
hist(circ)
subplot(1, 3, 2);
hist(circdark)
subplot(1, 3, 3);
hist(lin)

%%
load Fig2f-g-circ-updn-corr.mat
imagesc(m)

%%
load Fig2h-i-lin-updn-corr.mat
image(m)