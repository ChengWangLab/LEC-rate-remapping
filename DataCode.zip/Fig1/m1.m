 
load('linear-std-1-info', 'allinfo');
lin_info = allinfo;
load('circ-std-1-info', 'allinfo');
circ_info = allinfo;
load('DR-std-1-info', 'theinfo');
dr_info = theinfo;


edges = 0:0.05:1.5;
tick_length = 0.03;
xc = edges(1:end-1) + 0.01;

subplot(1, 3, 1);
dry = histc(dr_info, edges);
dry = dry(1:end-1);
bar(xc, dry, 'w', 'edgecolor', 'k');
set(gca, 'xlim', [0, 1.5]); box off; box off; set(gca, 'tickdir', 'out', 'ticklength', [tick_length, tick_length]);
title('DR')

subplot(1, 3, 2);
myy = histc(circ_info, edges);
myy = myy(1:end-1);
bar(xc, myy, 'w', 'edgecolor','k');
set(gca, 'xlim', [0, 1.5]); box off; set(gca, 'tickdir', 'out', 'ticklength', [tick_length, tick_length]);
title('circ')

subplot(1, 3, 3);
myy = histc(lin_info, edges);
myy = myy(1:end-1);
bar(xc, myy, 'w', 'edgecolor','k'); 
set(gca, 'xlim', [0, 1.5]); box off; set(gca, 'tickdir', 'out', 'ticklength', [tick_length, tick_length]);
title('lin')

